from collections.abc import Iterable, Iterator
from typing import Any
from simplibs.exception import ValidationError
# Outers
from ...base_class import Rule


class AllUnique(Rule):
    """Every item in an iterable value must be unique (no duplicates).

    Rule:
        len(set(value)) == len(value)

    Example:
        validate(value, AllUnique())
    """

    __slots__ = ()

    # ----------------------------------------------------------------------
    # Rule definition
    # ----------------------------------------------------------------------
    def is_valid(self, value: Any) -> bool:

        # 1. Handling for when value is not iterable
        if not isinstance(value, Iterable):
            return False

        # 2. A one-shot iterator would be consumed by this check — reject it untouched
        if isinstance(value, Iterator):
            return False

        # 3. Convert to a list for repeated inspection
        items = list(value)

        # 4. Evaluate item uniqueness
        # 4.1 Fast path for hashable items — O(n)
        try:
            return len(set(items)) == len(items)

        # 4.2 Fallback for unhashable items — O(n^2)
        except TypeError:
            seen: list[Any] = []
            for item in items:
                if item in seen:
                    return False
                seen.append(item)
            return True

    # ----------------------------------------------------------------------
    # Description definition
    # ----------------------------------------------------------------------
    def describe(self) -> str:

        # 1. Phrase built from the rule's parameters
        return "all unique"

    # ----------------------------------------------------------------------
    # Exception definition
    # ----------------------------------------------------------------------
    def build_exception(
        self,
        value: Any,
        value_name: str | None = None,
        context: str | None = None,
    ) -> Exception:

        # 1. Prepare data
        # 1.1 When value is not iterable
        if not isinstance(value, Iterable):
            problem = f"Value {value!r} of type '{type(value).__name__}' is not iterable."
            how_to_fix = "Provide an iterable container (e.g., list, tuple, set)."
            exception_type = TypeError

        # 1.2 When value is a one-shot iterator (validating it would have consumed it)
        elif isinstance(value, Iterator):
            problem = (
                f"Value of type '{type(value).__name__}' is a one-shot iterator: "
                "checking its items would consume it."
            )
            how_to_fix = "Pass a list, tuple or set (e.g. list(value)) instead of the iterator."
            exception_type = TypeError

        # 1.3 When value contains duplicates
        else:
            items = list(value)
            duplicates: list[Any] = []
            seen: list[Any] = []
            for item in items:
                if item in seen and item not in duplicates:
                    duplicates.append(item)
                else:
                    seen.append(item)

            problem = f"Value contains duplicate item(s): {duplicates!r}."
            how_to_fix = f"Remove duplicate item(s): {duplicates!r}."
            exception_type = ValueError

        # 2. Build the exception
        return ValidationError(
            error_name="ALL_UNIQUE_ERROR",
            label=value_name,
            expected="all-unique items",
            value=value,
            problem=problem,
            context=context,
            how_to_fix=how_to_fix,
            exception=exception_type,
        )


_DESIGN_NOTES = """
# AllUnique — Uniqueness Validation Rule for Iterables

## Purpose
The `AllUnique` rule validates that an iterable container contains no
duplicate elements.

---

## 1. Execution Rationale & Safeguards

* **Explicit Interface Guard (`is_valid`):**
  Uses an explicit `isinstance(value, Iterable)` check to safely reject
  non-iterable objects without catching unrelated runtime errors, and
  rejects one-shot iterators (see section 4).
* **Hybrid Uniqueness Inspection:**
  * Fast-path set inspection (`O(n)`) for hashable elements (integers,
    strings, tuples).
  * Catches `TypeError` if items are unhashable (e.g., lists, dicts) and
    falls back to iterative comparison (`O(n^2)`).
* **Dual Diagnostic Path (`build_exception`):**
  Uses internal `if/else` branching to assemble:
  * A `TypeError` when the input is not iterable.
  * A `TypeError` when the input is a one-shot iterator (the check would consume it).
  * A `ValueError` (`ALL_UNIQUE_ERROR`) when the input contains duplicates,
    explicitly listing all duplicate items.

---

## 2. Exception Card Design

* **Type Failures:** Evaluated inputs without `__iter__` support format
  problem/fix strings as `TypeError`.
* **Duplicate Failures:** Evaluated iterables with duplicate items format
  problem/fix strings as `ValueError` (`ALL_UNIQUE_ERROR`), listing exact
  duplicate values.

---

## 3. Description

`describe()` returns "all unique" — what the value must be. A short fragment that containers and
the typing layer compose into larger texts ("not ...", "... | ..."); the failure
card keeps its own `expected` sentence.

---

## 4. One-Shot Iterators Are Rejected, Not Consumed

This rule has to walk the whole value, and walking a generator (or any other
iterator) consumes it: the caller would get an exhausted iterator back, and
when the check fails, the diagnostics would re-read the already consumed value
and report nothing useful (an empty list of items). An iterator therefore
never reaches the check — `is_valid` returns `False` for it, and
`build_exception` explains why (`TypeError`, same `error_name` as the other
failures of this rule). Re-iterable containers (list, tuple, set, dict, range,
...) are unaffected.

The iterable test is `isinstance(value, Iterable)` rather than
`hasattr(value, "__iter__")`: `hasattr` is also true for a class object such as
`list` itself, which `list(value)` then rejects with a `TypeError` raised out of
`is_valid`. Same reasoning as `IsReiterable` and `Iterable[T]`.
"""
